import { useState, useEffect } from 'react';
import { motion, AnimatePresence, useScroll, useTransform } from 'motion/react';
import { 
  Github, Linkedin, Mail, MapPin, Calendar, GraduationCap, 
  Briefcase, Code2, Database, BrainCircuit, LineChart, ExternalLink, 
  Download, Terminal, BarChart2, Server, Globe 
} from 'lucide-react';

const ROLES = [
  "Data Analyst",
  "AI Data Scientist",
  "SQL Developer",
  "Python Developer",
  "Machine Learning Expert"
];

const SKILLS = [
  { name: "Python", percentage: 90 },
  { name: "Pandas & NumPy", percentage: 95 },
  { name: "Data Visualization", percentage: 90 },
  { name: "SQL", percentage: 85 },
  { name: "Statistics", percentage: 85 },
  { name: "EDA", percentage: 85 },
  { name: "Power BI", percentage: 80 },
  { name: "Excel", percentage: 80 },
  { name: "Machine Learning", percentage: 75 },
];

export default function App() {
  const [roleIndex, setRoleIndex] = useState(0);
  const [isScrolled, setIsScrolled] = useState(false);
  const { scrollYProgress } = useScroll();
  const opacity = useTransform(scrollYProgress, [0, 0.2], [1, 0]);
  const scale = useTransform(scrollYProgress, [0, 0.2], [1, 0.95]);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  useEffect(() => {
    const interval = setInterval(() => {
      setRoleIndex((prev) => (prev + 1) % ROLES.length);
    }, 2500);
    return () => clearInterval(interval);
  }, []);

  const scrollTo = (id: string) => {
    const el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen bg-[#030303] text-gray-300 font-sans selection:bg-indigo-500/30 selection:text-indigo-200 overflow-hidden">
      
      {/* High-Tech Background Atmosphere */}
      <div className="fixed inset-0 z-0 pointer-events-none">
        <div className="absolute top-[10%] left-[-10%] w-[50%] h-[50%] rounded-full bg-indigo-900/10 blur-[150px]"></div>
        <div className="absolute bottom-[10%] right-[-10%] w-[40%] h-[40%] rounded-full bg-blue-900/10 blur-[150px]"></div>
        <div className="absolute inset-0 bg-[url('https://transparenttextures.com/patterns/cubes.png')] opacity-[0.02]"></div>
      </div>

      {/* NAVBAR */}
      <motion.nav 
        initial={{ y: -100 }}
        animate={{ y: 0 }}
        transition={{ duration: 0.6, ease: "easeOut" }}
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 border-b ${
          isScrolled ? "bg-[#030303]/80 backdrop-blur-md border-white/10 py-4" : "bg-transparent border-transparent py-6"
        }`}
      >
        <div className="max-w-6xl mx-auto px-6 flex items-center justify-between">
          <div className="text-xl font-bold font-mono tracking-tighter text-white">MB.</div>
          <div className="hidden md:flex gap-6 text-sm font-medium">
            {["Home", "About", "Skills", "Projects", "Experience", "Contact"].map((item) => (
              <button 
                key={item} 
                onClick={() => scrollTo(item.toLowerCase())}
                className="hover:text-indigo-400 transition-colors"
              >
                {item}
              </button>
            ))}
          </div>
          <div className="flex items-center gap-4">
            <div className="hidden lg:flex items-center gap-2 text-xs font-semibold px-3 py-1.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
              Hire Me - Available
            </div>
          </div>
        </div>
      </motion.nav>

      <div className="relative z-10 max-w-6xl mx-auto px-6 pt-32 pb-24 space-y-32">
        
        {/* HERO SECTION */}
        <section id="home" className="min-h-[80vh] flex flex-col justify-center relative">
          <motion.div style={{ opacity, scale }} className="grid lg:grid-cols-2 gap-12 items-center">
            <motion.div 
              initial="hidden"
              animate="visible"
              variants={{
                hidden: { opacity: 0 },
                visible: {
                  opacity: 1,
                  transition: { staggerChildren: 0.2, delayChildren: 0.1 }
                }
              }}
              className="space-y-6"
            >
              <div className="space-y-4">
                <motion.h1 
                  variants={{
                    hidden: { opacity: 0, y: 40 },
                    visible: { opacity: 1, y: 0, transition: { duration: 0.8, ease: [0.16, 1, 0.3, 1] } }
                  }}
                  className="text-5xl md:text-7xl lg:text-8xl font-bold tracking-tighter text-white mb-2 leading-tight"
                >
                  Turning Data<br/>
                  <span className="text-transparent bg-clip-text bg-gradient-to-r from-indigo-400 to-cyan-400">Into Insights</span>
                </motion.h1>
                <motion.div 
                  variants={{
                    hidden: { opacity: 0, y: 30 },
                    visible: { opacity: 1, y: 0, transition: { duration: 0.8, ease: [0.16, 1, 0.3, 1] } }
                  }}
                  className="text-xl md:text-3xl text-gray-300 font-medium tracking-wide h-10 md:h-12 flex items-center overflow-hidden"
                >
                  <span className="mr-2">I am a</span>
                  <AnimatePresence mode="wait">
                    <motion.span
                      key={roleIndex}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -20 }}
                      transition={{ duration: 0.3, ease: "easeInOut" }}
                      className="text-indigo-400 font-bold font-mono"
                    >
                      {ROLES[roleIndex]}
                    </motion.span>
                  </AnimatePresence>
                </motion.div>
                <motion.p 
                  variants={{
                    hidden: { opacity: 0, y: 30 },
                    visible: { opacity: 1, y: 0, transition: { duration: 0.8, ease: [0.16, 1, 0.3, 1] } }
                  }}
                  className="text-gray-400 max-w-xl text-lg leading-relaxed mt-6"
                >
                  I help businesses make data-driven decisions through advanced analytics, machine learning, and intuitive visualizations.
                </motion.p>
              </div>

              <motion.div 
                variants={{
                  hidden: { opacity: 0, y: 20 },
                  visible: { opacity: 1, y: 0, transition: { duration: 0.8, ease: [0.16, 1, 0.3, 1] } }
                }}
                className="flex flex-wrap gap-4 pt-4"
              >
                <button onClick={() => scrollTo('projects')} className="px-6 py-3 rounded-lg bg-indigo-500 hover:bg-indigo-600 text-white font-medium transition-colors">
                  View Projects
                </button>
                <button onClick={() => scrollTo('contact')} className="px-6 py-3 rounded-lg bg-white/5 border border-white/10 hover:bg-white/10 text-white font-medium transition-colors">
                  Contact Me
                </button>
              </motion.div>
            </motion.div>

            {/* High Tech Stat Card */}
            <motion.div 
              initial={{ opacity: 0, scale: 0.9, x: 50 }}
              animate={{ opacity: 1, scale: 1, x: 0 }}
              transition={{ duration: 1, delay: 0.5, type: "spring" }}
              className="hidden lg:block relative"
            >
              <div className="absolute inset-0 bg-gradient-to-tr from-indigo-500/20 to-cyan-500/20 blur-2xl rounded-full"></div>
              <div className="relative border border-white/10 bg-black/40 backdrop-blur-xl p-8 rounded-2xl shadow-2xl">
                <div className="flex items-start justify-between mb-8">
                  <div className="p-3 bg-indigo-500/20 rounded-lg border border-indigo-500/30">
                    <BrainCircuit className="text-indigo-400" size={24} />
                  </div>
                  <Terminal size={20} className="text-gray-500" />
                </div>
                <div>
                  <div className="text-5xl font-bold text-white mb-2 tracking-tight">98%</div>
                  <div className="text-indigo-300 font-medium text-lg">Model Accuracy</div>
                  <div className="text-sm text-gray-500 font-mono mt-1">Random Forest Classifier</div>
                </div>
                
                {/* Decorative tech lines */}
                <div className="mt-8 pt-6 border-t border-white/5 flex gap-1">
                  {[...Array(20)].map((_, i) => (
                    <motion.div 
                      key={i}
                      initial={{ height: 4 }}
                      animate={{ height: Math.random() * 24 + 4 }}
                      transition={{ duration: 1, repeat: Infinity, repeatType: "reverse", delay: i * 0.1 }}
                      className="flex-1 bg-indigo-500/30 rounded-full"
                    />
                  ))}
                </div>
              </div>
            </motion.div>
          </motion.div>
        </section>

        {/* ABOUT SECTION */}
        <section id="about" className="space-y-12 pt-10">
          <SectionHeading>About</SectionHeading>
          
          <div className="grid lg:grid-cols-3 gap-12">
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="lg:col-span-2 space-y-6 text-lg leading-relaxed text-gray-300"
            >
              <h3 className="text-3xl font-bold text-white mb-6">Hi, I'm Mohit Boura</h3>
              <p>
                I am a BCom student and aspiring Data Scientist passionate about data analytics, machine learning, and business intelligence. I thrive on uncovering hidden patterns in complex datasets and translating them into actionable business strategies.
              </p>
              <p>
                Skilled in Python, SQL, Power BI, statistics, and exploratory data analysis. My background bridges the gap between technical data science and strategic business management, allowing me to build models that not only predict accurately but also drive real business value.
              </p>

              <div className="grid grid-cols-2 gap-6 pt-6 mt-6 border-t border-white/10">
                <div>
                  <div className="text-4xl font-bold text-white tracking-tight mb-1">20+</div>
                  <div className="text-emerald-400 font-medium">Projects Completed</div>
                </div>
                <div>
                  <div className="text-4xl font-bold text-white tracking-tight mb-1">1M+</div>
                  <div className="text-blue-400 font-medium">Rows Analyzed</div>
                </div>
              </div>
            </motion.div>

            <motion.div 
              initial={{ opacity: 0, x: 20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="space-y-6"
            >
              <div className="p-6 rounded-2xl bg-white/[0.02] border border-white/[0.05] hover:border-indigo-500/30 transition-all">
                <Code2 className="text-indigo-400 mb-4" size={24} />
                <h4 className="text-white font-semibold mb-2">Programming</h4>
                <p className="text-sm text-gray-400">Python & R for data manipulation, scripting, and predictive modeling.</p>
              </div>
              <div className="p-6 rounded-2xl bg-white/[0.02] border border-white/[0.05] hover:border-blue-500/30 transition-all">
                <Server className="text-blue-400 mb-4" size={24} />
                <h4 className="text-white font-semibold mb-2">Data Management</h4>
                <p className="text-sm text-gray-400">Complex SQL queries, database design, and data warehousing.</p>
              </div>
              <div className="p-6 rounded-2xl bg-white/[0.02] border border-white/[0.05] hover:border-pink-500/30 transition-all">
                <BarChart2 className="text-pink-400 mb-4" size={24} />
                <h4 className="text-white font-semibold mb-2">Visualization</h4>
                <p className="text-sm text-gray-400">Power BI, Tableau, and Matplotlib to tell stories with data.</p>
              </div>
            </motion.div>
          </div>
        </section>

        {/* SKILLS SECTION */}
        <section id="skills" className="space-y-12 pt-10">
          <SectionHeading>Technical Skills</SectionHeading>
          <div className="max-w-3xl mb-12">
            <p className="text-gray-400 text-lg">A comprehensive overview of my technical toolkit, from data manipulation and analysis to visualization and machine learning algorithms.</p>
          </div>
          
          <div className="grid md:grid-cols-2 gap-x-16 gap-y-8">
            {SKILLS.map((skill, index) => (
              <motion.div 
                key={skill.name}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="space-y-2"
              >
                <div className="flex justify-between items-end">
                  <span className="text-white font-medium">{skill.name}</span>
                  <span className="text-gray-500 font-mono text-sm">{skill.percentage}%</span>
                </div>
                <div className="h-2 w-full bg-white/10 rounded-full overflow-hidden">
                  <motion.div 
                    initial={{ width: 0 }}
                    whileInView={{ width: `${skill.percentage}%` }}
                    viewport={{ once: true }}
                    transition={{ duration: 1.5, ease: "easeOut", delay: 0.2 }}
                    className="h-full bg-gradient-to-r from-indigo-500 to-cyan-400 rounded-full"
                  />
                </div>
              </motion.div>
            ))}
          </div>
        </section>

        {/* PROJECTS SECTION */}
        <section id="projects" className="space-y-12 pt-10">
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
            <div className="space-y-4">
              <SectionHeading>Featured Projects</SectionHeading>
              <p className="text-gray-400 text-lg max-w-2xl">A selection of my recent work in data science, predictive modeling, and analytics.</p>
            </div>
            <a href="https://github.com/mohitboura342-ui" target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-2 text-indigo-400 hover:text-indigo-300 font-medium transition-colors">
              View All on GitHub <ExternalLink size={16} />
            </a>
          </div>

          <div className="grid md:grid-cols-2 gap-6">
            <ProjectCard 
              title="Telco Customer Churn Analysis"
              description="Developed a predictive model to identify customers at risk of leaving using telecom data. Implemented Random Forest and XGBoost to achieve 85% accuracy."
              tags={["Python", "Scikit-Learn", "Pandas", "EDA"]}
              link="https://github.com/mohitboura342-ui/telcom_churn-EDA"
            />
            <ProjectCard 
              title="E-Commerce Churn Prediction"
              description="An exploratory data analysis and modeling project focused on e-commerce datasets to understand sales trends and customer behavior."
              tags={["Python", "Machine Learning", "SQL", "Seaborn"]}
              link="https://github.com/mohitboura342-ui/E-commerce-project"
            />
            <ProjectCard 
              title="Zomato EDA Analysis"
              description="Explores restaurant ratings, online/offline services, and customer preferences using histograms, count plots, and pie charts."
              tags={["Python", "Pandas", "Matplotlib", "Seaborn"]}
              link="https://github.com/mohitboura342-ui/zomato-eda-analysis"
            />
            <ProjectCard 
              title="Learning Core Python"
              description="A notebook collection documenting the journey in core Python and libraries, including Matplotlib, NumPy, pandas, and scikit-learn."
              tags={["Python", "NumPy", "Pandas", "Scikit-Learn"]}
              link="https://github.com/mohitboura342-ui/LEARNING-CORE-PYTHON"
            />
            <ProjectCard 
              title="Used Car EDA"
              description="A repository with notebooks and plots for used-car exploratory data analysis work."
              tags={["Python", "Pandas", "Data Visualization", "EDA"]}
              link="https://github.com/mohitboura342-ui/Used-car-eda"
            />
          </div>
        </section>

        {/* EXPERIENCE & EDUCATION SECTION */}
        <section id="experience" className="space-y-12 pt-10">
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-12">
            <SectionHeading>Experience & Education</SectionHeading>
            <button className="inline-flex items-center gap-2 px-5 py-2.5 rounded-lg bg-indigo-500/10 text-indigo-400 border border-indigo-500/20 hover:bg-indigo-500/20 transition-colors font-medium">
              <Download size={18} /> Download Resume
            </button>
          </div>

          <div className="grid lg:grid-cols-2 gap-16">
            {/* Experience */}
            <div className="space-y-8">
              <h3 className="text-2xl font-semibold text-white flex items-center gap-3">
                <Briefcase className="text-indigo-400" /> Experience
              </h3>
              <div className="relative pl-8 border-l border-white/10 space-y-12 pb-4">
                <TimelineItem 
                  date="Sep 2025 - Present"
                  title="Data Science Intern (Training)"
                  subtitle="vijAI Robotics Pvt Ltd"
                  description="Hands-on experience in data analysis, machine learning, and statistical modeling. Executed data cleaning, EDA, feature engineering, and model building using Python (pandas, NumPy, scikit-learn, matplotlib)."
                />
              </div>
            </div>

            {/* Education */}
            <div className="space-y-8">
              <h3 className="text-2xl font-semibold text-white flex items-center gap-3">
                <GraduationCap className="text-indigo-400" /> Education
              </h3>
              <div className="relative pl-8 border-l border-white/10 space-y-12 pb-4">
                <TimelineItem 
                  date="Jul 2025 - Jul 2028"
                  title="Bachelor of Commerce - BCom, Analytics & Technology"
                  subtitle="Uttarakhand Open University"
                  description="Focusing on analytics, technology, and commerce fundamentals."
                />
                <TimelineItem 
                  date="Completed"
                  title="High School / Intermediate"
                  subtitle="Uttarakhand Board of School Education (UBSE)"
                  description="Foundational education and coursework."
                />
              </div>
            </div>
          </div>
        </section>

        {/* CONTACT SECTION */}
        <section id="contact" className="pt-10">
          <div className="p-12 rounded-3xl bg-gradient-to-b from-white/[0.05] to-transparent border border-white/[0.05] relative overflow-hidden">
            <div className="absolute top-0 right-0 p-32 bg-indigo-500/10 blur-[100px] rounded-full pointer-events-none"></div>
            
            <div className="relative z-10 grid md:grid-cols-2 gap-12 items-center">
              <div>
                <h2 className="text-4xl font-bold text-white mb-4">Let's Work Together</h2>
                <p className="text-gray-400 text-lg mb-8 max-w-md">
                  I'm currently available for new opportunities. Whether you have a question or just want to say hi, I'll try my best to get back to you!
                </p>
                <div className="space-y-4">
                  <ContactLink icon={<Mail size={20}/>} label="mohitboura342@gmail.com" href="mailto:mohitboura342@gmail.com" />
                  <ContactLink icon={<Linkedin size={20}/>} label="LinkedIn Profile" href="https://linkedin.com/in/mohit-boura-558382379" />
                  <ContactLink icon={<Github size={20}/>} label="GitHub Projects" href="https://github.com/mohitboura342-ui" />
                </div>
              </div>
              
              <div className="bg-[#030303]/80 p-8 rounded-2xl border border-white/10">
                <form className="space-y-4" onSubmit={(e) => e.preventDefault()}>
                  <div className="space-y-4">
                    <input type="text" placeholder="Name" className="w-full bg-white/5 border border-white/10 rounded-lg px-4 py-3 text-white placeholder:text-gray-600 focus:outline-none focus:border-indigo-500 transition-colors" />
                    <input type="email" placeholder="Email" className="w-full bg-white/5 border border-white/10 rounded-lg px-4 py-3 text-white placeholder:text-gray-600 focus:outline-none focus:border-indigo-500 transition-colors" />
                    <textarea placeholder="Message" rows={4} className="w-full bg-white/5 border border-white/10 rounded-lg px-4 py-3 text-white placeholder:text-gray-600 focus:outline-none focus:border-indigo-500 transition-colors resize-none"></textarea>
                  </div>
                  <button className="w-full py-4 rounded-lg bg-indigo-500 hover:bg-indigo-600 text-white font-medium transition-colors">
                    Send Message
                  </button>
                </form>
              </div>
            </div>
          </div>
        </section>

        {/* FOOTER */}
        <footer className="pt-20 pb-8 text-center text-gray-500 text-sm">
          <p>© {new Date().getFullYear()} Mohit Boura. All rights reserved.</p>
        </footer>
      </div>
    </div>
  );
}

function SectionHeading({ children }: { children: React.ReactNode }) {
  return (
    <motion.h2 
      initial={{ opacity: 0, x: -20 }}
      whileInView={{ opacity: 1, x: 0 }}
      viewport={{ once: true }}
      className="text-3xl lg:text-4xl font-bold text-white tracking-tight flex items-center gap-6"
    >
      {children}
      <div className="h-[1px] flex-grow bg-gradient-to-r from-white/20 to-transparent"></div>
    </motion.h2>
  );
}

function ProjectCard({ title, description, tags, link }: { title: string, description: string, tags: string[], link?: string }) {
  const CardContent = (
    <div className="h-full flex flex-col justify-between">
      <div>
        <h3 className="text-xl font-bold text-white mb-3 group-hover:text-indigo-400 transition-colors flex justify-between items-start">
          {title}
          {link && <ExternalLink size={20} className="opacity-50 group-hover:opacity-100 transition-opacity" />}
        </h3>
        <p className="text-gray-400 leading-relaxed mb-6">
          {description}
        </p>
      </div>
      <div className="flex flex-wrap gap-2">
        {tags.map(tag => (
          <span key={tag} className="px-3 py-1 rounded bg-white/5 border border-white/10 text-xs font-medium text-gray-300">
            {tag}
          </span>
        ))}
      </div>
    </div>
  );

  const wrapperClass = "block group h-full p-8 rounded-2xl bg-white/[0.02] border border-white/[0.05] hover:bg-white/[0.04] hover:border-indigo-500/30 transition-all duration-300 relative overflow-hidden";

  if (link) {
    return (
      <motion.a 
        href={link} target="_blank" rel="noopener noreferrer"
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        className={wrapperClass}
      >
        <div className="absolute top-0 right-0 w-32 h-32 bg-indigo-500/10 rounded-bl-full translate-x-16 -translate-y-16 group-hover:translate-x-8 group-hover:-translate-y-8 transition-transform duration-500"></div>
        {CardContent}
      </motion.a>
    );
  }

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      className={wrapperClass}
    >
      {CardContent}
    </motion.div>
  );
}

function TimelineItem({ date, title, subtitle, description }: any) {
  return (
    <motion.div 
      initial={{ opacity: 0, x: -20 }}
      whileInView={{ opacity: 1, x: 0 }}
      viewport={{ once: true }}
      className="relative"
    >
      <div className="absolute -left-[41px] top-1 w-[18px] h-[18px] rounded-full bg-[#030303] border-4 border-indigo-500"></div>
      <div className="text-sm font-mono text-indigo-400 mb-2">{date}</div>
      <h4 className="text-xl font-bold text-white mb-1">{title}</h4>
      <div className="text-gray-400 font-medium mb-3">{subtitle}</div>
      <p className="text-gray-500 leading-relaxed max-w-lg">{description}</p>
    </motion.div>
  );
}

function ContactLink({ icon, label, href }: { icon: React.ReactNode, label: string, href: string }) {
  return (
    <a href={href} target="_blank" rel="noopener noreferrer" className="flex items-center gap-4 group">
      <div className="p-3 rounded-xl bg-white/5 group-hover:bg-indigo-500/20 text-gray-400 group-hover:text-indigo-400 transition-colors border border-white/5 group-hover:border-indigo-500/20">
        {icon}
      </div>
      <span className="text-gray-300 font-medium group-hover:text-white transition-colors">{label}</span>
    </a>
  );
}

